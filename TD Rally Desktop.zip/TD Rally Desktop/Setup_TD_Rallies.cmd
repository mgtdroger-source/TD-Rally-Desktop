@echo off
REM TD Rallies – one‑click setup (double‑click this file)
REM Runs the PowerShell shortcut creator next to this file.
powershell -ExecutionPolicy Bypass -NoProfile -File "%~dp0Create_TD_Rallies_Desktop_Shortcut.ps1"
