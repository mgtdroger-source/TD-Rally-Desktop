# TD Rallies – Create Desktop Shortcut
# Place this script in the SAME folder as Launch_TD_Rallies.cmd and TD_simple.ico
# Best run: Right‑click → Run with PowerShell
# For normal double‑click setup, run Setup_TD_Rallies.cmd (provided separately).

$ErrorActionPreference = "Stop"

try {
  $base     = Split-Path -Parent $MyInvocation.MyCommand.Path
  $launcher = Join-Path $base "System\Launch_TD_Rallies.cmd"
  $icon     = Join-Path $base "TD_simple.ico"

  # Validate required files (fail loudly)
  if (!(Test-Path -LiteralPath $launcher)) { throw "Missing file: $launcher" }
  if (!(Test-Path -LiteralPath $icon))     { throw "Missing file: $icon" }

  $desktop = [Environment]::GetFolderPath("Desktop")
  if ([string]::IsNullOrWhiteSpace($desktop) -or !(Test-Path -LiteralPath $desktop)) {
    throw "Desktop path not found: $desktop"
  }

  $shortcutPath = Join-Path $desktop "TD Rallies.lnk"

  $WshShell  = New-Object -ComObject WScript.Shell
  $shortcut  = $WshShell.CreateShortcut($shortcutPath)

  $shortcut.TargetPath        = $launcher
  $shortcut.WorkingDirectory  = $base
  $shortcut.IconLocation      = $icon
  $shortcut.Save()

  Write-Host "Desktop shortcut created: TD Rallies"
  Write-Host "Target: $launcher"
  Write-Host "Icon:   $icon"
  Write-Host "Where:  $shortcutPath"
}
catch {
  Write-Host ""
  Write-Host "FAILED: $($_.Exception.Message)"
}
finally {
}
